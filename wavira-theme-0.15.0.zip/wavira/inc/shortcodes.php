<?php
/**
 * Server-rendered content shortcodes used by the block templates.
 *
 * Block templates are HTML, so anything that must read music data is exposed as
 * a shortcode and rendered by PHP. Both shortcodes here go through the public
 * function API of Wavira Core and degrade to an empty string when the plugin is
 * inactive — a template never fatals because a music feature is missing.
 *
 * The attribute value `current` resolves to the queried object, which is what a
 * template means when it says "this album" or "this genre".
 *
 * The dynamic blocks (wavira/blocks/) render through the same markup helpers, so
 * classic content and block content cannot drift apart.
 *
 * @package Wavira\Theme
 * @since   0.6.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wavira_shortcode_post_id' ) ) {
	/**
	 * Resolve a shortcode ID attribute.
	 *
	 * @param mixed $value Attribute value: a number or the word `current`.
	 * @return int Post ID, 0 when it cannot be resolved.
	 */
	function wavira_shortcode_post_id( $value ) {
		if ( is_string( $value ) && 'current' === strtolower( trim( $value ) ) ) {
			return (int) get_queried_object_id();
		}

		return absint( $value );
	}
}

if ( ! function_exists( 'wavira_shortcode_term_slug' ) ) {
	/**
	 * Resolve a shortcode slug attribute.
	 *
	 * @param mixed $value Attribute value: a slug or the word `current`.
	 * @return string Sanitised slug, empty string when it cannot be resolved.
	 */
	function wavira_shortcode_term_slug( $value ) {
		if ( is_string( $value ) && 'current' === strtolower( trim( $value ) ) ) {
			$term = get_queried_object();

			return $term instanceof WP_Term ? (string) $term->slug : '';
		}

		return sanitize_title( (string) $value );
	}
}

/**
 * Print the ordered tracklist of an album.
 *
 * Works without JavaScript, which is the point: the player's queue panel needs
 * the engine, but an album page must still list its tracks and link to them
 * (progressive enhancement, PERFORMANCE-AUDIT P2).
 *
 * @param array<string, mixed>|string $atts Shortcode attributes (`id`, `duration`, `subtitle`).
 * @return string Markup, empty string when there is nothing to show.
 */
function wavira_tracklist_shortcode( $atts = array() ) {
	$atts     = shortcode_atts(
		array(
			'id'       => 'current',
			'duration' => '1',
			'subtitle' => '1',
		),
		$atts,
		'wavira_tracklist'
	);
	$album_id = wavira_shortcode_post_id( $atts['id'] );

	if ( $album_id < 1 ) {
		return '';
	}

	return wavira_get_tracklist(
		$album_id,
		array(
			'show_duration' => (bool) filter_var( $atts['duration'], FILTER_VALIDATE_BOOLEAN ),
			'show_subtitle' => (bool) filter_var( $atts['subtitle'], FILTER_VALIDATE_BOOLEAN ),
		)
	);
}
add_shortcode( 'wavira_tracklist', 'wavira_tracklist_shortcode' );

/**
 * Print the video of a video post: a hosted file, an oEmbed, or nothing.
 *
 * @param array<string, mixed>|string $atts Shortcode attributes (`id`).
 * @return string Markup, empty string when the post has no video.
 */
function wavira_video_shortcode( $atts = array() ) {
	$atts    = shortcode_atts(
		array(
			'id' => 'current',
		),
		$atts,
		'wavira_video'
	);
	$post_id = wavira_shortcode_post_id( $atts['id'] );

	if ( $post_id < 1 ) {
		return '';
	}

	return wavira_get_video( $post_id );
}
add_shortcode( 'wavira_video', 'wavira_video_shortcode' );

/**
 * Print a complete artist page section: profile, works and gallery.
 *
 * The classic-editor surface of the `wavira/artist-profile` block. Both call
 * `wavira_get_artist()`, so a shortcode and a block cannot drift apart.
 *
 * @param array<string, mixed>|string $atts `id` (or `current`), `sections`,
 *                                          `limit`, `gallery`, `columns`.
 * @return string Markup, empty string when there is nothing to show.
 */
function wavira_artist_shortcode( $atts = array() ) {
	$atts = shortcode_atts(
		array(
			'id'       => 'current',
			'sections' => 'albums,tracks,videos',
			'limit'    => '6',
			'gallery'  => '8',
			'columns'  => '3',
		),
		$atts,
		'wavira_artist'
	);

	$artist_id = wavira_shortcode_post_id( $atts['id'] );

	if ( $artist_id < 1 ) {
		return '';
	}

	return wavira_get_artist(
		$artist_id,
		array(
			'sections'      => array_filter( array_map( 'sanitize_key', explode( ',', (string) $atts['sections'] ) ) ),
			'limit'         => absint( $atts['limit'] ),
			'gallery_limit' => absint( $atts['gallery'] ),
			'columns'       => absint( $atts['columns'] ),
		)
	);
}
add_shortcode( 'wavira_artist', 'wavira_artist_shortcode' );

/**
 * Print an artist photo gallery.
 *
 * @param array<string, mixed>|string $atts `id` (or `current`), `limit`, `columns`.
 * @return string Markup, empty string when the artist has no photos.
 */
function wavira_gallery_shortcode( $atts = array() ) {
	$atts = shortcode_atts(
		array(
			'id'      => 'current',
			'limit'   => '12',
			'columns' => '3',
		),
		$atts,
		'wavira_gallery'
	);

	$artist_id = wavira_shortcode_post_id( $atts['id'] );

	if ( $artist_id < 1 ) {
		return '';
	}

	return wavira_get_artist_gallery_only(
		$artist_id,
		array(
			'limit'   => absint( $atts['limit'] ),
			'columns' => absint( $atts['columns'] ),
		)
	);
}
add_shortcode( 'wavira_gallery', 'wavira_gallery_shortcode' );

/**
 * Print the site's news feed.
 *
 * @param array<string, mixed>|string $atts `count`, `category`, `date`, `excerpt`, `image`.
 * @return string Markup, empty string when there is nothing to show.
 */
function wavira_news_shortcode( $atts = array() ) {
	$atts = shortcode_atts(
		array(
			'count'    => '6',
			'category' => '',
			'date'     => '1',
			'excerpt'  => '1',
			'image'    => '1',
		),
		$atts,
		'wavira_news'
	);

	return wavira_get_news(
		array(
			'limit'        => absint( $atts['count'] ),
			'source'       => '' === (string) $atts['category'] ? 'blog' : 'category',
			'category'     => function_exists( 'wavira_shortcode_term_slug' ) ? sanitize_title( (string) $atts['category'] ) : '',
			'show_date'    => (bool) filter_var( $atts['date'], FILTER_VALIDATE_BOOLEAN ),
			'show_excerpt' => (bool) filter_var( $atts['excerpt'], FILTER_VALIDATE_BOOLEAN ),
			'show_image'   => (bool) filter_var( $atts['image'], FILTER_VALIDATE_BOOLEAN ),
		)
	);
}
add_shortcode( 'wavira_news', 'wavira_news_shortcode' );

/**
 * Print the items related to the post being viewed.
 *
 * The same cards the single templates show at the foot of the page: whatever
 * the plugin scores as related to this track, album, artist or video. A site
 * owner can therefore put the section inside an article, not only below it.
 *
 * @param array<string, mixed>|string $atts `id` (`current` or a post ID), `count`, `title`.
 * @return string Markup, empty string when there is nothing related.
 */
function wavira_related_shortcode( $atts = array() ) {
	$atts = shortcode_atts(
		array(
			'id'    => 'current',
			'count' => '6',
			'title' => '',
		),
		$atts,
		'wavira_related'
	);

	if ( ! function_exists( 'wavira_get_related' ) ) {
		return '';
	}

	return wavira_get_related(
		array(
			'post_id' => function_exists( 'wavira_shortcode_post_id' ) ? wavira_shortcode_post_id( $atts['id'] ) : 0,
			'limit'   => absint( $atts['count'] ),
			'title'   => (string) $atts['title'],
		)
	);
}
add_shortcode( 'wavira_related', 'wavira_related_shortcode' );
