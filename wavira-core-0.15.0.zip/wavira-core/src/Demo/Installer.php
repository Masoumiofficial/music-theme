<?php
/**
 * Install the demo content — the one code path behind every door.
 *
 * `wp wavira seed` and the admin screen `Tools → Wavira demo content` both call
 * `Installer::install()`; keeping the two in sync by hand is how a demo drifts
 * from the product it demonstrates. The routine is idempotent by default: a site
 * that already has tracks is left alone unless the caller forces a second run.
 *
 * Two rules, both inherited from the CLI command this replaced:
 *
 * - **No fabricated media.** Audio and video files are never seeded. A demo URL
 *   that 404s is worse than no URL: the player would look broken on the first
 *   click a buyer makes. The catalogue carries the metadata a music site needs
 *   (artists, releases, tracklists, durations, lyrics, genres, kinds) and lets
 *   the buyer add their own files.
 * - **Fictional content only.** Every lyric, biography and title is written for
 *   the demo (ADR 0010); nothing is copied from a real artist or song.
 *
 * @package Wavira\Core
 */

namespace Wavira\Core\Demo;

use RuntimeException;
use Wavira\Core\Content\MetaSchema;
use Wavira\Core\Content\PostTypes;
use Wavira\Core\Content\Taxonomies;
use WP_Post;
use WP_Classic_To_Block_Menu_Converter;
use WP_Term;

defined( 'ABSPATH' ) || exit;

/**
 * Class Installer
 */
final class Installer {

	/**
	 * Post meta that marks a post as demo content this tool created.
	 *
	 * It is what makes a second import safe: a forced run removes exactly the
	 * posts carrying this marker (and their attachments are never deleted),
	 * while anything the site owner wrote is left untouched.
	 */
	public const MARKER = '_wavira_demo';

	/**
	 * Install the demo catalogue.
	 *
	 * @param array<string, mixed> $args `force` (bool), `english` (bool),
	 *                                   `site` (bool: touch site options and the
	 *                                   menu, default true).
	 * @return array<string, mixed> Report: `skipped`, `artist`, `releases`,
	 *                              `tracks`, `video`, `menu`, `notices`.
	 * @throws RuntimeException When WordPress refuses to create a post.
	 */
	public static function install( array $args = array() ): array {
		// The content types have to exist before anything is written for them.
		// They are registered on `init`, and an import does not always get its own
		// request: a setup wizard, or a command that activates the plugin and seeds
		// the site in one breath, runs after `init` has already fired — and a menu
		// item for an archive whose post type is not registered is *invalid*, which
		// WordPress drops without a word. It showed up as a demo menu with only
		// «خانه» in it.
		self::ensure_content_types();

		$force   = ! empty( $args['force'] );
		$english = ! empty( $args['english'] );
		$site    = ! array_key_exists( 'site', $args ) || ! empty( $args['site'] );

		$report = array(
			'skipped'  => false,
			'artist'   => 0,
			'releases' => array(),
			'tracks'   => array(),
			'video'    => 0,
			'news'     => array(),
			'menu'     => 0,
			'replaced' => 0,
			'media'    => 0,
			'notices'  => array(),
		);

		if ( self::has_tracks() && ! $force ) {
			$report['skipped']   = true;
			$report['notices'][] = __( 'Tracks already exist — nothing was imported. Use force to import anyway.', 'wavira-core' );

			return $report;
		}

		$demo = $english ? Fixtures::english() : Fixtures::persian();

		if ( $force ) {
			$report['replaced'] = self::remove_previous( $english ? 'english' : 'persian' );
		}

		Taxonomies::ensure_kind_terms();

		$report['artist'] = self::insert_demo_post( PostTypes::ARTIST, $demo['artist'] );

		if ( Placeholders::cover( $report['artist'], self::palette( 4 ), (string) $demo['artist']['title'], 800 ) > 0 ) {
			++$report['media'];
		}

		// The gallery is content, not a site setting: `$site` decides whether the
		// language, timezone and date formats are touched, and a demo whose
		// artist page has an empty gallery (or whose album page offers no
		// download) because somebody chose the narrowly-scoped import is a demo
		// that does not demonstrate the product (ADR 0024).
		for ( $photo = 1; $photo <= 6; $photo++ ) {
			$id = Placeholders::photo(
				$report['artist'],
				self::palette( 4 + $photo ),
				(string) $demo['artist']['title'] . $photo,
				$photo
			);

			if ( $id > 0 ) {
				++$report['media'];
			}
		}

		$release_index = 0;

		foreach ( $demo['releases'] as $release ) {
			$release_id = self::insert_demo_post( PostTypes::ALBUM, $release );

			update_post_meta( $release_id, MetaSchema::ARTIST, $report['artist'] );
			update_post_meta( $release_id, MetaSchema::ALBUM_TYPE, (string) $release['type'] );
			update_post_meta( $release_id, MetaSchema::RELEASE_DATE, (string) $release['release_date'] );
			update_post_meta( $release_id, MetaSchema::VIEWS_OFFSET, 3400 + ( $release_index * 850 ) );
			update_post_meta( $release_id, MetaSchema::LIKES_OFFSET, 240 + ( $release_index * 65 ) );

			self::attach_term( $release_id, Taxonomies::GENRE, (string) $release['genre'] );

			// The demo ships generated media, never a URL that can 404 (ADR 0010
			// amended by ADR 0024): a cover per release, a tone per track so the
			// player and the download button have a file, a photo set for the
			// artist and a poster for the video.
			$palette = self::palette( $release_index );
			$cover   = Placeholders::cover( $release_id, $palette, (string) $release['title'] );

			if ( $cover > 0 ) {
				++$report['media'];
			}

			$album_file = Placeholders::album_audio( $release_id, 8, 262 + ( $release_index * 55 ) );

			if ( $album_file > 0 ) {
				++$report['media'];
			}

			$release_tracks = array();

			foreach ( $release['tracks'] as $index => $track ) {
				$track_id = self::insert_demo_post(
					PostTypes::TRACK,
					array(
						'title'      => (string) $track['title'],
						'date'       => (string) $track['date'],
						'menu_order' => $index + 1,
					)
				);

				update_post_meta( $track_id, MetaSchema::ARTIST, $report['artist'] );
				update_post_meta( $track_id, MetaSchema::ALBUM, $release_id );
				update_post_meta( $track_id, MetaSchema::DURATION, (int) $track['duration'] );
				update_post_meta( $track_id, MetaSchema::LYRICS, (string) $track['lyrics'] );
				update_post_meta( $track_id, MetaSchema::RELEASE_DATE, (string) $track['date'] );
				update_post_meta( $track_id, MetaSchema::VIEWS_OFFSET, 1200 + ( $index * 340 ) + ( $release_index * 210 ) );
				update_post_meta( $track_id, MetaSchema::LIKES_OFFSET, 85 + ( $index * 24 ) + ( $release_index * 15 ) );

				if ( 'podcast' === (string) ( $track['kind'] ?? 'music' ) ) {
					update_post_meta( $track_id, MetaSchema::EPISODE, 1 );
					update_post_meta(
						$track_id,
						MetaSchema::CHAPTERS,
						$english
							? "00:00 Intro\n00:02 Studio Conversation\n00:04 Outro"
							: "00:00 مقدمه و معرفی\n00:02 گفت‌وگوی استودیویی\n00:04 جمع‌بندی و پایان"
					);
				}

				if ( ! empty( $track['featured'] ) ) {
					update_post_meta( $track_id, MetaSchema::FEATURED, true );
				}

				self::attach_term( $track_id, Taxonomies::GENRE, (string) $track['genre'] );
				self::attach_kind( $track_id, (string) ( $track['kind'] ?? 'music' ) );

				$track_cover = Placeholders::cover( $track_id, $palette, (string) $track['title'], 600 );

				if ( $track_cover > 0 ) {
					++$report['media'];
				}

				$audio = Placeholders::audio( $track_id, 6, 330 + ( $index * 42 ) );

				if ( ! empty( $audio['id'] ) ) {
					$report['media'] += (int) ( $audio['files'] ?? 1 );

					// The demo's own file length is what the player shows while
					// nothing has loaded yet: six seconds of tone, not the four
					// minutes the fixture pretends the song lasts.
					update_post_meta( $track_id, MetaSchema::DURATION, 6 );
				}

				$release_tracks[] = $track_id;
			}

			$report['tracks'] = array_merge( $report['tracks'], $release_tracks );

			update_post_meta( $release_id, MetaSchema::TRACKLIST, $release_tracks );

			$report['releases'][] = $release_id;
			++$release_index;
		}

		$report['video'] = self::insert_demo_post( PostTypes::VIDEO, $demo['video'] );

		update_post_meta( $report['video'], MetaSchema::ARTIST, $report['artist'] );
		update_post_meta( $report['video'], MetaSchema::ALBUM, (int) reset( $report['releases'] ) );
		update_post_meta( $report['video'], MetaSchema::VIDEO_SOURCE, 'other' );

		// The video has a poster so the section is not an empty box; there is no
		// video *file*, and the block says so plainly instead of pointing at a
		// file that is not there (see docs/adr/0024-generated-demo-media.md).
		if ( Placeholders::cover( $report['video'], self::palette( 3 ), (string) $demo['video']['title'], 960 ) > 0 ) {
			++$report['media'];
		}

		// The news is ordinary posts, because that is what news is. They carry
		// the same marker as the music, so a forced import replaces them and
		// still leaves the posts the owner wrote alone — an «اخبار» page that
		// lists nothing but the sample post WordPress installs is an empty
		// section where the product promises a working one.
		foreach ( $demo['news'] as $index => $article ) {
			$post_id = self::insert_demo_post( 'post', $article );

			// Not appended: WordPress puts a new post in the site's default
			// category, and a news card that reads «دسته‌بندی‌نشده» next to
			// «تازه‌ها» says the demo was never finished.
			self::attach_term( $post_id, 'category', (string) $article['category'], false );

			if ( Placeholders::cover( $post_id, self::palette( 5 + $index ), (string) $article['title'], 800, __( 'Demo news image', 'wavira-core' ) ) > 0 ) {
				++$report['media'];
			}

			$report['news'][] = $post_id;
		}

		if ( ! $english && $site ) {
			$report['notices'] = array_merge( $report['notices'], self::apply_site_defaults( $demo ) );
			$report['menu']    = self::create_primary_menu( $demo );
		}

		/**
		 * Fires after the demo content was installed.
		 *
		 * @since 0.11.0
		 * @param array<string, mixed> $report Install report.
		 * @param array<string, mixed> $demo   Fixture that was installed.
		 */
		do_action( 'wavira_core_demo_installed', $report, $demo );

		return $report;
	}

	/**
	 * Cover palette of the demo.
	 *
	 * Covers are generated, so their colours are the one thing that makes two
	 * releases distinguishable in a grid. The set is deliberately dark-to-mid: the
	 * theme's accent is indigo and a demo of pastel covers would look like a
	 * different product.
	 *
	 * @param int $index Palette number; wraps around.
	 * @return array<int, array<int, int>> Two RGB triples.
	 */
	private static function palette( int $index ): array {
		$palettes = array(
			array( array( 27, 32, 74 ), array( 118, 96, 232 ) ),   // Indigo night.
			array( array( 12, 74, 86 ), array( 92, 214, 195 ) ),   // Persian turquoise.
			array( array( 84, 24, 44 ), array( 240, 138, 122 ) ),  // Warm sunset.
			array( array( 18, 18, 24 ), array( 108, 122, 148 ) ),  // Charcoal.
			array( array( 52, 38, 12 ), array( 226, 178, 92 ) ),   // Amber.
			array( array( 16, 52, 38 ), array( 138, 214, 138 ) ),  // Garden.
			array( array( 60, 20, 60 ), array( 226, 128, 214 ) ),  // Orchid.
		);

		return $palettes[ $index % count( $palettes ) ];
	}

	/**
	 * Whether the site already holds tracks.
	 *
	 * @return bool
	 */
	public static function has_tracks(): bool {
		$count = wp_count_posts( PostTypes::TRACK );

		return isset( $count->publish ) && (int) $count->publish > 0;
	}

	/**
	 * Insert one demo post, failing loudly when WordPress refuses.
	 *
	 * The caller gets an exception rather than a half-installed catalogue: a
	 * partial demo is harder to diagnose than a failed import.
	 *
	 * @param string               $post_type Post type.
	 * @param array<string, mixed> $data      Title, content, date and menu order.
	 * @return int Post ID.
	 * @throws RuntimeException When the post cannot be created.
	 */
	private static function insert_demo_post( string $post_type, array $data ): int {
		$post_id = wp_insert_post(
			array(
				'post_type'    => $post_type,
				'post_title'   => (string) ( $data['title'] ?? '' ),
				'post_content' => (string) ( $data['content'] ?? '' ),
				'post_excerpt' => (string) ( $data['excerpt'] ?? '' ),
				'post_status'  => 'publish',
				'post_date'    => (string) ( $data['date'] ?? '' ),
				'menu_order'   => (int) ( $data['menu_order'] ?? 0 ),
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			throw new RuntimeException( $post_id->get_error_message() ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- the caller escapes it for the surface it prints on.
		}

		if ( (int) $post_id <= 0 ) {
			throw new RuntimeException( 'WordPress did not create the demo post.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- a fixed string, never user input.
		}

		update_post_meta( (int) $post_id, self::MARKER, '1' );

		return (int) $post_id;
	}

	/**
	 * Remove the demo content a previous run created.
	 *
	 * Only posts carrying the marker are deleted, and they are deleted in pages
	 * so a large catalogue cannot exhaust memory on a shared host. Nothing here
	 * touches media: an attachment the owner uploaded under a demo title stays.
	 *
	 * @param string $fixture Fixture name, for the log.
	 * @return int Number of posts deleted.
	 */
	private static function remove_previous( string $fixture ): int {
		$deleted = 0;
		$types   = array( PostTypes::ARTIST, PostTypes::ALBUM, PostTypes::TRACK, PostTypes::VIDEO, 'post' );

		// The generated attachments go first, and separately: a forced import
		// that deleted its titles and left twenty-three files in the uploads
		// folder would fill a site with orphans (ADR 0024). `wp_delete_attachment()`
		// removes the file with the row, so nothing is unlinked by hand; only
		// files this importer wrote carry the marker.
		$deleted += self::remove_previous_media();

		do {
			$ids = get_posts(
				array(
					'post_type'        => $types,
					'post_status'      => 'any',
					'posts_per_page'   => 100,
					'fields'           => 'ids',
					'orderby'          => 'ID',
					'order'            => 'ASC',
					'no_found_rows'    => true,
					'suppress_filters' => false,
					'meta_key'         => self::MARKER, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- an administrative one-off, not a front-end query.
					'meta_value'       => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- same.
				)
			);

			foreach ( $ids as $id ) {
				if ( wp_delete_post( (int) $id, true ) ) {
					++$deleted;
				}
			}
		} while ( array() !== $ids );

		/**
		 * Fires after a forced import removed the demo content of a previous run.
		 *
		 * @since 0.11.0
		 * @param int    $deleted Number of posts removed.
		 * @param string $fixture Fixture that is about to be installed.
		 */
		do_action( 'wavira_core_demo_replaced', $deleted, $fixture );

		return $deleted;
	}

	/**
	 * Attach one term of a taxonomy, creating it on first use.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $taxonomy Taxonomy name.
	 * @param string $name     Term name.
	 * @param bool   $append   Add the term to the post's terms (default) or make
	 *                         it the only one. A new post is already in the
	 *                         site's default category, so a demo news post
	 *                         replaces it rather than joining it — otherwise
	 *                         every card reads «دسته‌بندی‌نشده» beside its own
	 *                         category.
	 * @return void
	 */
	private static function attach_term( int $post_id, string $taxonomy, string $name, bool $append = true ): void {
		if ( '' === $name || ! taxonomy_exists( $taxonomy ) ) {
			return;
		}

		$term = term_exists( $name, $taxonomy );

		if ( ! $term ) {
			$term = wp_insert_term( $name, $taxonomy );
		}

		if ( is_wp_error( $term ) || ! is_array( $term ) || ! isset( $term['term_id'] ) ) {
			return;
		}

		wp_set_object_terms( $post_id, array( (int) $term['term_id'] ), $taxonomy, $append );
	}

	/**
	 * Attach the kind term of a demo track.
	 *
	 * The kind is what the archive filter and — for imported content — the
	 * migration tool use, so the demo declares one per track: the default demo
	 * ships songs and a remix of one of them, which is enough to show that a
	 * remix is not just another song on the shelf.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $kind    Kind slug or a source value.
	 * @return void
	 */
	private static function attach_kind( int $post_id, string $kind ): void {
		$slug = Taxonomies::normalize_kind( $kind );

		if ( '' === $slug ) {
			return;
		}

		self::attach_term( $post_id, Taxonomies::KIND, $slug );
	}

	/**
	 * The Iranian defaults a Persian music site expects.
	 *
	 * Public because the public API exposes it as
	 * `wavira_core_apply_persian_defaults()` and the theme's one-click Persian
	 * setup calls that function: one implementation of "what a Persian site
	 * needs", shared by the demo installer and the theme.
	 *
	 * @param array<string, mixed> $demo Demo catalogue (its `site` block carries
	 *                                   the locale, timezone and description).
	 * @return string[] Notices for the report.
	 */
	public static function apply_site_defaults( array $demo ): array {
		update_option( 'WPLANG', (string) $demo['site']['locale'] );
		update_option( 'timezone_string', (string) $demo['site']['timezone'] );
		update_option( 'start_of_week', 6 );
		update_option( 'date_format', 'j F Y' );
		update_option( 'time_format', 'H:i' );

		$description = (string) get_option( 'blogdescription' );

		// Only replace a description nobody wrote on purpose.
		if ( '' === trim( $description ) || 'Just another WordPress site' === $description ) {
			update_option( 'blogdescription', (string) $demo['site']['description'] );
		}

		$notices = array(
			__( 'Site locale, timezone, first day of the week and date format were set to the Iranian defaults.', 'wavira-core' ),
		);

		$notices = array_merge( $notices, self::ensure_news_page() );

		$first = self::translate_first_content();

		if ( $first > 0 ) {
			$notices[] = sprintf(
				/* translators: %d: number of sample posts and pages. */
				__( 'WordPress’s sample content (%d item(s)) now reads in the site’s language.', 'wavira-core' ),
				$first
			);
		}

		return $notices;
	}

	/**
	 * Give the news an address of its own.
	 *
	 * The front page is the theme's own template, so the posts archive has no
	 * URL until the site says which page is which: `page_for_posts` only means
	 * anything when the front page is a static page, and a fresh WordPress
	 * install shows posts on the front page instead. Without both, the news
	 * section of the front page offers a «مشاهدهٔ همه» that leads back to
	 * itself, and the template that lists posts is unreachable.
	 *
	 * Bounded like the rest of the installer: a site that has already chosen a
	 * page for either slot keeps it.
	 *
	 * @return string[] Notices for the report.
	 */
	private static function ensure_news_page(): array {
		if ( 'page' === (string) get_option( 'show_on_front' ) && absint( get_option( 'page_for_posts' ) ) > 0 ) {
			return array();
		}

		$front_id = absint( get_option( 'page_on_front' ) );

		if ( $front_id < 1 ) {
			$front_id = self::ensure_page( __( 'Home', 'wavira-core' ) );
		}

		$news_id = self::ensure_page( __( 'News', 'wavira-core' ) );

		// Two different pages are what makes the pair mean anything; anything
		// less is left as it was rather than half-set.
		if ( $front_id < 1 || $news_id < 1 || $front_id === $news_id ) {
			return array();
		}

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_id );
		update_option( 'page_for_posts', $news_id );

		return array(
			__( 'The news have a page of their own: the front page is static now, and the posts are listed at their own address.', 'wavira-core' ),
		);
	}

	/**
	 * One published page by title, reused when a page of that name exists.
	 *
	 * @param string $title Page title. WordPress derives the slug from it, so
	 *                      the lookup matches what a second import would find.
	 * @return int Page ID, or 0 when WordPress refused to create it.
	 */
	private static function ensure_page( string $title ): int {
		$slug  = sanitize_title( $title );
		$found = get_posts(
			array(
				'post_type'      => 'page',
				'name'           => $slug,
				'posts_per_page' => 1,
				'post_status'    => array( 'publish', 'draft', 'private' ),
			)
		);

		if ( isset( $found[0] ) && $found[0] instanceof WP_Post ) {
			return (int) $found[0]->ID;
		}

		$page_id = wp_insert_post(
			array(
				'post_type'   => 'page',
				'post_title'  => $title,
				'post_status' => 'publish',
				'post_name'   => $slug,
			),
			true
		);

		return is_wp_error( $page_id ) ? 0 : (int) $page_id;
	}

	/**
	 * Put WordPress's own sample content into the site's language.
	 *
	 * A fresh install is not Persian because the theme and the plugin are: core
	 * creates “Hello world!”, a sample page and an “Uncategorized” category, and
	 * the front page's news section shows all three — English content inside a
	 * Persian site, which is the one thing a visitor notices first (0.15.0's
	 * render found it: the page read «اخبار موسیقی» above “Hello world!”).
	 *
	 * Bounded and polite: only the canonical slugs core itself writes are touched,
	 * so anything the owner renamed is left alone, and the texts come from the
	 * catalogue rather than from a string typed here.
	 *
	 * @return int Number of items whose text was replaced.
	 */
	private static function translate_first_content(): int {
		$changed = 0;

		$category = get_term_by( 'slug', 'uncategorized', 'category' );

		if ( $category instanceof WP_Term ) {
			$name = __( 'Uncategorized', 'wavira-core' );

			if ( $name !== (string) $category->name ) {
				wp_update_term(
					(int) $category->term_id,
					'category',
					array(
						'name' => $name,
						'slug' => sanitize_title( $name ),
					)
				);
				++$changed;
			}
		}

		$samples = array(
			array(
				'slug'    => 'hello-world',
				'type'    => 'post',
				'title'   => __( 'Welcome to the music site', 'wavira-core' ),
				'content' => __( 'This is your first post. Edit it, replace it with your own news, or delete it — the front page has a section for whatever you publish here.', 'wavira-core' ),
				// Core dates it at install time, which makes it the newest post
				// on the site and puts a placeholder at the head of the news
				// section, above the demo's own news. Dated behind the
				// catalogue, it still teaches what it has to teach.
				'date'    => '2025-10-15',
			),
			array(
				'slug'    => 'sample-page',
				'type'    => 'page',
				'title'   => __( 'About the site', 'wavira-core' ),
				'content' => __( 'This is a sample page. Write what your visitors should know about the music, the artists and how to reach you.', 'wavira-core' ),
			),
		);

		foreach ( $samples as $sample ) {
			$title = (string) $sample['title'];

			// Core's slug, then the one this function writes when it translates
			// the post: a second import has to be able to find its own work, or
			// the sample content is translated once and never touched again —
			// and the date above is never applied at all.
			$slugs = array_unique( array( (string) $sample['slug'], sanitize_title( $title ) ) );
			$post  = null;

			foreach ( $slugs as $slug ) {
				// A direct `post_name` lookup rather than `get_page_by_path()`:
				// the helper is built for hierarchical post types, and the
				// sample post is not one.
				$found = get_posts(
					array(
						'post_type'        => (string) $sample['type'],
						'name'             => $slug,
						'posts_per_page'   => 1,
						'post_status'      => array( 'publish', 'draft', 'pending', 'private' ),
						'suppress_filters' => true,
					)
				);

				if ( isset( $found[0] ) && $found[0] instanceof WP_Post ) {
					$post = $found[0];
					break;
				}
			}

			if ( ! $post instanceof WP_Post ) {
				continue;
			}

			$update = array(
				'ID'           => (int) $post->ID,
				'post_title'   => $title,
				'post_content' => (string) $sample['content'],
				'post_name'    => sanitize_title( $title ),
			);

			// Only the sample post carries a date: a post that predates the
			// demo belongs behind it, and the sample page has no order to keep.
			if ( '' !== (string) ( $sample['date'] ?? '' ) ) {
				$update['post_date'] = (string) $sample['date'];
			}

			wp_update_post( $update );
			++$changed;
		}

		return $changed;
	}

	/**
	 * Delete the attachments a previous import generated.
	 *
	 * Bounded and marker-scoped: a real site's uploads never carry
	 * `Placeholders::MARKER`, so nothing an owner uploaded can be touched.
	 *
	 * @return int Number of attachments deleted.
	 */
	private static function remove_previous_media(): int {
		$deleted = 0;

		do {
			$ids = get_posts(
				array(
					'post_type'        => 'attachment',
					'post_status'      => 'any',
					'posts_per_page'   => 100,
					'fields'           => 'ids',
					'no_found_rows'    => true,
					'suppress_filters' => false,
					'meta_key'         => Placeholders::MARKER, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- administrative one-off.
					'meta_value'       => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- same.
				)
			);

			foreach ( $ids as $id ) {
				if ( wp_delete_attachment( (int) $id, true ) ) {
					++$deleted;
				}
			}
		} while ( array() !== $ids );

		return $deleted;
	}

	/**
	 * Register the music content types when this request has not done it yet.
	 *
	 * `PostTypes` and `Taxonomies` do their work on `init`. An import that runs
	 * in the same request that activated the plugin — a setup wizard, or a CLI
	 * that activates and seeds in one command — runs after that hook has fired,
	 * and then every post type this importer writes into is unknown: posts of an
	 * unregistered type are still created (WordPress does not check the type when
	 * inserting), but a menu item pointing at their archive is invalid, and the
	 * menu a visitor sees comes out short.
	 *
	 * @return void
	 */
	private static function ensure_content_types(): void {
		if ( ! post_type_exists( PostTypes::TRACK ) ) {
			( new PostTypes() )->register_post_types();
		}

		if ( ! taxonomy_exists( Taxonomies::GENRE ) ) {
			( new Taxonomies() )->register_taxonomies();
		}
	}

	/**
	 * Build the theme's primary menu from the demo catalogue.
	 *
	 * @param array<string, mixed> $demo Demo catalogue.
	 * @return int Menu ID, 0 when the menu could not be created.
	 */
	private static function create_primary_menu( array $demo ): int {
		$name    = (string) $demo['menu']['name'];
		$menu_id = wp_create_nav_menu( $name );

		if ( is_wp_error( $menu_id ) ) {
			$existing = wp_get_nav_menu_object( $name );

			if ( ! $existing ) {
				return 0;
			}

			$menu_id = (int) $existing->term_id;

			// The menu already exists, and every item in it is about to be added
			// again: importing the demo twice used to leave the site owner with a
			// menu twice over, which is what clicking Import a second time does.
			// The menu is the demo's, so a re-run replaces it rather than appends
			// to it.
			foreach ( (array) wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) ) as $item ) {
				wp_delete_post( (int) $item->ID, true );
			}
		}

		foreach ( (array) $demo['menu']['items'] as $item ) {
			$args = array(
				'menu-item-title'  => (string) $item['label'],
				'menu-item-status' => 'publish',
			);

			if ( 'archive' === $item['type'] ) {
				$args['menu-item-type']   = 'post_type_archive';
				$args['menu-item-object'] = (string) $item['object'];
			} elseif ( 'taxonomy' === $item['type'] ) {
				$term_id = (int) ( $item['object_id'] ?? 0 );

				if ( ! $term_id ) {
					// A taxonomy has no archive of its own — only a term has a
					// page — so an item naming a taxonomy and no term renders as
					// `<a href="">`: a link with no destination, which goes to the
					// page you are already on. Better to leave it out.
					continue;
				}

				$args['menu-item-type']      = 'taxonomy';
				$args['menu-item-object']    = (string) $item['object'];
				$args['menu-item-object-id'] = $term_id;
			} elseif ( 'posts' === $item['type'] ) {
				$posts_page = absint( get_option( 'page_for_posts' ) );

				// The page that lists the posts is the site's choice, not the
				// demo's — and it may not exist at all. A menu item with no
				// destination is a link to the page you are already on, so it
				// is left out instead.
				if ( $posts_page < 1 ) {
					continue;
				}

				$args['menu-item-type']      = 'post_type';
				$args['menu-item-object']    = 'page';
				$args['menu-item-object-id'] = $posts_page;
			} else {
				$args['menu-item-type'] = 'custom';
				$args['menu-item-url']  = (string) $item['url'];
			}

			wp_update_nav_menu_item( (int) $menu_id, 0, $args );
		}

		// Read-modify-write of the nav menu locations, as its own step.
		$locations = (array) get_theme_mod( 'nav_menu_locations', array() );

		$locations['primary'] = (int) $menu_id;

		set_theme_mod( 'nav_menu_locations', $locations );

		$menu = get_term( (int) $menu_id, 'nav_menu' );

		if ( $menu instanceof WP_Term ) {
			self::publish_block_menu( $menu );
		}

		return (int) $menu_id;
	}

	/**
	 * Publish the block navigation the theme actually renders.
	 *
	 * The theme's two Navigation blocks live in template parts and name no menu,
	 * so core renders the most recently published `wp_navigation` post - and on a
	 * site that has none yet, it converts the classic menu into one the first
	 * time a page is rendered. That conversion happens once and is never
	 * refreshed: importing the demo twice left the front page showing the menu
	 * exactly as it was after the first import, however the menu in wp-admin
	 * looked. Publishing the converted menu here means the menu a visitor sees is
	 * the menu this importer just built, on every run.
	 *
	 * The conversion is core's own (`WP_Classic_To_Block_Menu_Converter`), so the
	 * markup is the markup the editor would produce.
	 *
	 * @since 0.15.0
	 * @param WP_Term $menu The classic menu that was just built.
	 * @return int Post ID of the block menu, 0 when it could not be written.
	 */
	private static function publish_block_menu( WP_Term $menu ): int {
		// `::class` and not a string: inside a namespace, `'WP_Classic_To_Block_…'`
		// is `Wavira\Core\Demo\WP_Classic_To_Block_…` to PHP - which does not
		// exist, and which `class_exists()` reports as existing because it asks
		// the autoloader with the name as written.
		if ( ! class_exists( WP_Classic_To_Block_Menu_Converter::class ) ) {
			return 0;
		}

		$blocks = WP_Classic_To_Block_Menu_Converter::convert( $menu );

		if ( is_wp_error( $blocks ) || '' === $blocks ) {
			return 0;
		}

		$args = array(
			'post_type'    => 'wp_navigation',
			'post_status'  => 'publish',
			'post_title'   => (string) $menu->name,
			'post_name'    => (string) $menu->slug,
			'post_content' => $blocks,
		);

		$existing = get_posts(
			array(
				'post_type'      => 'wp_navigation',
				'name'           => (string) $menu->slug,
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);

		if ( $existing ) {
			$args['ID'] = (int) $existing[0];
		}

		$post_id = wp_insert_post( $args, true );

		return is_wp_error( $post_id ) ? 0 : (int) $post_id;
	}
}
