<?php /* Template Name: خواننده ها */ get_header(''); ?>
<?php get_template_part('inc/breadcrumbs'); ?>
<!-- centers_box -->
<div class="tarlanweb_center">
<div id="centers_box">
<div class="clear2"></div>
<div class="song_boxs singers_box_tarlanweb">
<div class="songs_title_box">
<h3>لیست هنرمندان </h3>
<div class="clear"></div>
</div>

<div class="song_boxs_posts">
<?php
//get_query_var to get page id from url
$page = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
// number of tags to show per-page
$per_page = 18;
//count total number of terms related to passed taxonomy
$number_of_series = count(get_terms('singer'));
$offset = ( $page - 1 ) * $per_page;
$term_args = array(
    'number' => $per_page,'orderby' => 'name',
    'offset' => $offset
);
$terms = get_terms('singer', $term_args);
if ($terms) { 
echo '<ul>';
foreach ($terms as $term) { $term_link = get_term_link( $term ); $image = get_field('aimg2', $term); ?>
<li><a href="<?php echo esc_url( $term_link ); ?>">
<?php if ($image !=""){ ?> 
<img src="<?php echo $image; ?>" width="200" height="200" alt="<?php echo $term->name; ?>" title="<?php echo $term->name; ?>">
<?php } else{ ?>
<img src="<?php echo get_template_directory_uri(); ?>/images/def-singer.webp" width="200" height="200" alt="<?php echo $term->name; ?>" title="<?php echo $term->name; ?>">
<?php } ?>
<span><?php echo $term->name; ?></span></a></li>
<?php    }
    //foreach ends
   ?>
<div class="clear"></div>
</div>
</div>

<div class="pagination_box_artist">
<?php if (function_exists("pagination")) {
        $big = 999999999;
 
        //your function for pagination or plugin you added for pagination
       //get_template_part('inc/pagination');
        echo paginate_links(array(
                            'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                            'format' => '?paged=%#%',
                            'current' => $paged,
                            'total' => ceil($number_of_series / $per_page) // like 10 items per page
                        ));
 } ?>
</div>
<?php
echo '</ul>';
} ?>

<div class="clear2"></div>
</div>
</div>
<!-- centers_box -->
<?php get_footer(''); ?>