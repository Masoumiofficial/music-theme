<?php get_header(''); ?>
<?php get_template_part('inc/breadcrumbs'); ?>
<?php $term = get_queried_object(); ?>



<div class="tarlanweb_center">
<div class="artist_box_tarlanweb">

<div class="artists_imsf">
<?php $image = get_field('aimg2', $term); if ($image !=""){ ?> 
<img src="<?php echo $image; ?>" width="200" height="200" alt="<?php echo $term->name; ?>" title="<?php echo $term->name; ?>">
<?php } else{ ?>
<img src="<?php echo get_template_directory_uri(); ?>/images/def-singer.webp" width="200" height="200" alt="<?php echo $term->name; ?>" title="<?php echo $term->name; ?>">
<?php } ?>
<div class="socials_box">
<span>صفحات مجازی خواننده</span>
<?php if(get_field('afacebook',$term)){ ?><a href="<?php echo get_field('afacebook', $term); ?>" class="icofont-facebook"></a><?php } if(get_field('atelegram',$term)){ ?><a href="<?php echo get_field('atelegram', $term); ?>" class="icofont-paper-plane"></a><?php } if(get_field('ainstagram',$term)){ ?><a href="<?php echo get_field('ainstagram', $term); ?>" class="icofont-instagram"></a><?php } if(get_field('atwitter',$term)){ ?><a href="<?php echo get_field('atwitter', $term); ?>" class="icofont-twitter"></a><?php } if(get_field('ayoutube',$term)){ ?><a href="<?php echo get_field('ayoutube', $term); ?>" class="icofont-youtube-play"></a><?php } ?>
<div class="clear"></div>
</div><div class="clear"></div>
</div>

<div class="artist_box_detss">
<?php $queried_object = get_queried_object(); $term_id = $queried_object->slug;
$query=new WP_Query(array(
'meta_query'=>array(array('key'=>'musics_type','value'=>'mp3','compare'=>'=')),
'tax_query' => array(array('taxonomy'=>'singer','field'=>'slug','terms'=>$term_id,'operator'=>'IN')),));
$query1=new WP_Query(array(
'meta_query'=>array(array('key'=>'musics_type','value'=>'mp4','compare'=>'=')),
'tax_query' => array(array('taxonomy'=>'singer','field'=>'slug','terms'=>$term_id,'operator'=>'IN')),));
$query2=new WP_Query(array(
'meta_query'=>array(array('key'=>'musics_type','value'=>'album','compare'=>'=')),
'tax_query' => array(array('taxonomy'=>'singer','field'=>'slug','terms'=>$term_id,'operator'=>'IN')),)); ?>

<h1 class="artist_name_head">دانلود آهنگ های <?php single_term_title(); ?></h1>	

<ul class="artist_resume_box">
<?php if($query->have_posts()): ?> 
<li> <?php echo $query->found_posts; ?> آهنگ</li><?php endif; if($query1->have_posts()): ?>
<li> <?php echo $query1->found_posts; ?> موزیک ویدیو</li><?php endif; if($query2->have_posts()): ?> 
<li> <?php echo $query2->found_posts; ?> آلبوم </li><?php endif; ?>
</ul>
<div class="clear2"></div>

<?php if (! empty(the_archive_description(''))) { ?> 
<div class="artist_txt_box">
<?php the_archive_description(''); ?>
<div class="clear"></div>
</div>
<?php } ?>

</div>

<div class="clear"></div>
</div>
</div>





<div id="artist_box">

<!-- centers_box -->
<div class="tarlanweb_center">
<div id="centers_box">

<?php $queried_object=get_queried_object(); $term_id = $queried_object->slug;
$rkianoosh= new WP_Query(array('post_type'=>'post','posts_per_page'=>'-1','orderby'=>'date','order'=>'DESC',
'meta_query'=>array(array('key'=>'musics_type','value'=>'album','compare'=>'=')),
'tax_query'=>array(array('taxonomy'=>'singer','field'=>'slug','terms'=>$term_id,'operator'=>'IN')),
)); if($rkianoosh->have_posts()) : ?>
<!-- song_boxs -->
<div class="song_boxs">
<div class="songs_title_box">
<h3>آلبوم ها</h3>
<div class="clear"></div><div class="liner"></div>
</div>
<div class="song_boxs_posts">
<ul>
<?php while($rkianoosh->have_posts()) : $rkianoosh->the_post();?> 
<li><?php get_template_part('inc/songs_post'); ?></li>
<?php endwhile; wp_reset_postdata(); ?>
</ul>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<!-- song_boxs -->
<?php endif; wp_reset_query(); ?>

<?php $queried_object = get_queried_object(); $term_id = $queried_object->slug;
$my_query= new WP_Query(array('post_type'=>'post','posts_per_page'=>'-1','orderby'=>'date','order'=>'DESC',
'meta_query'=>array(array('key'=>'musics_type','value'=>'mp3','compare'=>'=')),
'tax_query' => array(array('taxonomy'=>'singer','field'=>'slug','terms'=>$term_id,'operator'=>'IN')),
)); if($my_query->have_posts()) : ?>
<!-- song_boxs -->
<div class="song_boxs">
<div class="songs_title_box">
<h3>آهنگ ها</h3>
<div class="clear"></div><div class="liner"></div>
</div>
<div class="song_boxs_posts">
<ul>
<?php while($my_query->have_posts()) : $my_query->the_post();?> 
<li><?php get_template_part('inc/songs_post'); ?></li>
<?php endwhile; wp_reset_postdata(); ?>
</ul>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<!-- song_boxs -->
<?php endif; wp_reset_query(); ?>

<?php $queried_object = get_queried_object(); $term_id = $queried_object->slug;
$my_custom= new WP_Query(array('post_type'=>'post','posts_per_page'=>'-1','orderby'=>'date','order'=>'DESC',
'meta_query'=>array(array('key'=>'musics_type','value'=>'mp4','compare'=>'=')),
'tax_query'=>array(array('taxonomy'=>'singer','field'=>'slug','terms'=>$term_id,'operator'=>'IN')),
)); if($my_custom->have_posts()) : ?>
<!-- song_boxs -->
<div class="song_boxs">
<div class="songs_title_box">
<h3>موزیک ویدیو ها</h3>
<div class="clear"></div><div class="liner"></div>
</div>
<div class="song_boxs_posts">
<ul>
<?php while($my_custom->have_posts()) : $my_custom->the_post();?> 
<li><?php get_template_part('inc/songs_post'); ?></li>
<?php endwhile; wp_reset_postdata(); ?>
</ul>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<!-- song_boxs -->
<?php endif; wp_reset_query(); ?>

<div class="clear"></div>
</div>
</div>
<!-- centers_box -->

</div>

<?php get_footer(''); ?>