<div class="fulls_post_txt p404-textc">
<img class="aligncenter" src="<?php bloginfo('template_url'); ?>/images/error404.jpg" width="626" height="496" alt="خطای 404" title="خطای 404">
<p>خطای 404 نشان دهنده اینست که مطلبی که به دنبال آن هستید وجود ندارد. ممکن است حذف شده باشد و یا اصلا نوشته نشده باشد. </p>
<p> اگر مطمعن  هستید قبلا چنین مطلبی در سایت منتشر شده، از طریق فرم تماس و یا راه های ارتباطی با مدیران سایت تماس بگیرید.
<p>در حال هدایت به صفحه اصلی ...</p>
<script>
(function($) { $(document).ready(function(){
window.onload = function(){(function(){ var counter = 15; setInterval(function(){ counter--;
if(counter >= 0){span = document.getElementById("count");
span.innerHTML = counter;} if(counter === 0){clearInterval(counter);}}, 1000); })(); }
function go2NewUrl(newUrl, sec){setTimeout("location.href='" + newUrl + "'", sec * 1000);}
go2NewUrl('<?php bloginfo('url'); ?>', 15);
});
}(jQuery));
</script>
<div class="clear"></div>
</div>