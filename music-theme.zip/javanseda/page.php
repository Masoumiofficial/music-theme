<?php get_header(''); ?>
<?php get_template_part('inc/breadcrumbs'); ?>
<!-- centers_box -->
<div class="tarlanweb_center">
<div id="centers_box">
<!-- single_posts_right -->
<div class="single_posts_right">
<?php if(have_posts()) : while(have_posts()) : the_post(); ?>
<article class="single_posts tarlanweb_post_box">
<header>
<h1><?php the_title(); ?></h1>
<div class="liner clear"></div>
<?php if(function_exists('the_views')){ ?>
<div class="tarlanweb_post_ft"><i class="icofont-eye-alt"></i> <?php the_views(); ?></div><?php } ?>
<div class="clear"></div>
</header>
<div class="single_content_box">
<?php the_content(''); ?>
<div class="clear"></div>
</div>
<footer>
</footer>
<div class="clear"></div>
</article>
<?php endwhile; endif; ?>
<div class="clear"></div>
</div>
<!-- single_posts_right -->
<div id="left_side">
<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('left_side1')) : endif; ?>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
</div>
<!-- centers_box -->
<?php get_footer(''); ?>